from django.forms import ModelForm
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from .models import Profile, Skill, Message


class CustomUserCreationForm(UserCreationForm):
    class Meta:
        model = User
        fields = ['first_name', 'email', 'username', 'password1']
        labels = {
            'first_name': 'Наименование организации',
            'email' : 'Электронная почта',
            'username' : 'Логин',
            'password1' : 'Пароль',

        }

    def __init__(self, *args, **kwargs):
        super(CustomUserCreationForm, self).__init__(*args, **kwargs)

        for name, field in self.fields.items():
            field.widget.attrs.update({'class': 'input'})


class ProfileForm(ModelForm):
    class Meta:
        model = Profile
        fields = ['name', 'email', 'username',
                  'city', 'bio', 'website', 'image', 'INN', 'KPP', 'OGRN', 'contact']
        labels = {
            'name' : 'Имя',
            'email' : 'Электронная почта',
            'username' : 'Логин',
            'city' : 'Город',
            'bio' : 'Информация',
            'website' : 'Веб-сайт',
            'image' : 'Аватарка',
            'INN' : 'ИНН',
            'KPP' : 'КПП',
            'OGRN' : 'ОГРН',
            'contact' : 'Контактные данные',

        }

    def __init__(self, *args, **kwargs):
        super(ProfileForm, self).__init__(*args, **kwargs)

        for name, field in self.fields.items():
            field.widget.attrs.update({'class': 'input'})


class SkillForm(ModelForm):
    class Meta:
        model = Skill
        fields = '__all__'
        exclude = ['owner']

    def __init__(self, *args, **kwargs):
        super(SkillForm, self).__init__(*args, **kwargs)

        for name, field in self.fields.items():
            field.widget.attrs.update({'class': 'input'})




class MessageForm(ModelForm):
    class Meta:
        model = Message
        fields = ['name', 'email', 'subject', 'body']
        labels = {
            'name' : 'Имя',
            'email' : 'Электронная почта',
            'subject' : 'Тема',
            'body' : 'Сообщение',


        }

    def __init__(self, *args, **kwargs):
        super(MessageForm, self).__init__(*args, **kwargs)

        for name, field in self.fields.items():
            field.widget.attrs.update({'class': 'input'})
